package com.fms.service;

import java.util.List;

import com.fms.pojo.*;

public interface IFilmService {
	public String addFilm(Film film);
	public String modifyFilm(Film film);
	public String deleteFilm(String title);
	public List<Film> searchFilmBytitle(String title);
	public List<Film> searchFilmByCategory(Category category);
	public List<Film> searchFilmByRating(byte rating);
	public List<Film> searchFilmByLanguage(String language);
	public List<Film> searchFilmByActor(Actor actor);

}
