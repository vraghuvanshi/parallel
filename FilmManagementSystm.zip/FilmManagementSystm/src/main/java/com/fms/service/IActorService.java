package com.fms.service;

import java.util.List;

import com.fms.pojo.Actor;


public interface IActorService {
	public String addActor(Actor actor);
	public String modifyActor(Actor actor);
	public String deleteActor(String firstName);
	public List<Actor> searchActorByFristName(String firstName);

}
