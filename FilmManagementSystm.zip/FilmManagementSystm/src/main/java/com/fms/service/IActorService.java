package com.fms.service;

import java.util.List;

import com.fms.pojo.Actor;


public interface IActorService {
	public String addActor(Actor actor);
	public String modifyActor(Actor actor);
	public String deleteActor(Actor actor);
	public List<Actor> searchActorByName(String firstName,String lastNAme);
	public List<Actor> searchActorByAge(byte Age);

}
