package com.fms.service;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;



import com.fms.Doa.IFilmDoa;
import com.fms.pojo.Actor;
import com.fms.pojo.Category;
import com.fms.pojo.Film;

import junit.framework.TestCase;


public class FilmServiceTest{
	
	private FilmService filmService;
	
	@Mock private IFilmDoa filmRepository;
	
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
		filmService=new FilmService(filmRepository);
		
	}
	
	@Test
	public void filmDetailsAdded(){
		Film film =new Film();
		film.setActor(new ArrayList<Actor>());
		film.setCategory(new ArrayList<Category>());
		film.setCreateDate(new Date());
		film.setDeleteDate(null);
		film.setDescriptor("Good film");
		film.setLanguage("Hindi");
		film.setLength((short) 120);
		film.setRating((byte) 1);
		film.setReleaseDate(new Date());
		film.setTitle("Rockstar");
		
		
		
		Mockito.when(filmRepository.addFilm(film)).thenReturn("success");
		assertEquals("success", filmService.addFilm(film));	
	}	
	

	@Test (expected=IllegalArgumentException.class)
	public void filmdetailsIsNull(){
		Mockito.when(filmRepository.addFilm(null)).thenThrow(new IllegalArgumentException("Error"));
		filmService.addFilm(null);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void titleIsNull(){
		Mockito.when(filmRepository.searchFilmBytitle(null)).thenThrow(new IllegalArgumentException("Error"));
		filmService.searchFilmBytitle(null);
	}
	
	
	@Test
	public void  searchFilmByTitle(){
		List<Film> list=new ArrayList<Film>();
		Film film=new Film();
		film.setTitle("Rockstar");
		list.add(film);
		
		Mockito.when(filmRepository.searchFilmBytitle("Rockstar")).thenReturn(list);
		assertNotNull(filmService.searchFilmBytitle("Rockstar"));
		
		
		
	}
	
	
	
	
	
	

}
