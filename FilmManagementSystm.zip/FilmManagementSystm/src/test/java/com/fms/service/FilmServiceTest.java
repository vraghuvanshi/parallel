package com.fms.service;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;



import com.fms.Doa.IFilmDoa;
import com.fms.pojo.Actor;
import com.fms.pojo.Category;
import com.fms.pojo.Film;

import junit.framework.TestCase;


public class FilmServiceTest{
	
	private FilmService filmService;
	
	@Mock private IFilmDoa filmRepository;
	
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
		filmService=new FilmService(filmRepository);
		
	}
	
	//-----------------AddFilm test cases---------------------------------
	
	//1) Film Details Added Successfully
	
	@Test
	public void filmDetailsAdded(){
		Film film =new Film();
		film.setActor(new ArrayList<Actor>());
		film.setCategory(new ArrayList<Category>());
		film.setCreateDate(new Date());
		film.setDeleteDate(null);
		film.setDescriptor("Good film");
		film.setLanguage("Hindi");
		film.setLength((short) 120);
		film.setRating((byte) 1);
		film.setReleaseDate(new Date());
		film.setTitle("Rockstar");
		
		
		
		Mockito.when(filmRepository.addFilm(film)).thenReturn("success");
		assertEquals("success", filmService.addFilm(film));	
	}	
	
	
	//2) Film Details not added
	@Test
	public void filmDetailsNotAdded(){
		Film film =new Film();
		film.setActor(new ArrayList<Actor>());
		film.setCategory(new ArrayList<Category>());
		film.setCreateDate(new Date());
		film.setDeleteDate(null);
		film.setDescriptor("Good film");
		film.setLanguage("Hindi");
		film.setLength((short) 120);
		film.setRating((byte) 1);
		film.setReleaseDate(new Date());
		film.setTitle("Rockstar");
		
		
		
		Mockito.when(filmRepository.addFilm(film)).thenReturn("fail");
		assertEquals("fail", filmService.addFilm(film));	
	}	
	
	
	
	
	//3) Film Cann't be null
	@Test (expected=IllegalArgumentException.class)
	public void filmdetailsIsNull(){
		filmService.addFilm(null);
	}
	
	
	
	
	//---------------------------Modify film Test Cases------------------------------------
	
	
	@Test (expected=IllegalArgumentException.class)
	public void modifyFilmdetailsIsNull(){
		filmService.addFilm(null);
	}
	
	@Test
	public void filmModifySuccess(){
		List<Film> list=new ArrayList<Film>();
		Film film=new Film();
		film.setTitle("Rockon");
		
		Mockito.when(filmRepository.modifyFilm(film)).thenReturn("success");
		assertEquals("success",filmService.modifyFilm(film));
	}
	
	
	@Test
	public void filmModifyFailure(){
		List<Film> list=new ArrayList<Film>();
		Film film=new Film();
		film.setTitle("Rockon");
		
		Mockito.when(filmRepository.modifyFilm(film)).thenReturn("success");
		assertEquals("success",filmService.modifyFilm(film));
	}
	
	
	
	
	
	//--------------------- search Film By title test cases----------------------------------------
	
	
	@Test(expected=IllegalArgumentException.class)
	public void titleIsNull(){
		filmService.searchFilmBytitle(null);
	}
	
	
	@Test
	public void  filmFoundByTitle(){
		List<Film> list=new ArrayList<Film>();
		Film film=new Film();
		film.setTitle("Rockstar");
		list.add(film);
		
		Mockito.when(filmRepository.searchFilmBytitle("Rockstar")).thenReturn(list);
		
		list=filmService.searchFilmBytitle("Rockstar");
		Iterator<Film> it=list.iterator();
		assertEquals("Rockstar",it.next().getTitle());
	
		
	}
	
	

	@Test
	public void  filmNotFoundByTitle(){
		List<Film> list=new ArrayList<Film>();
		
		Mockito.when(filmRepository.searchFilmBytitle("Rockon")).thenReturn(list);
		
		assertTrue(filmService.searchFilmBytitle("Rockon").isEmpty());
	
		
	}
	
	
	
	
	
	
	//------------------------ Search By Category Test----------------------------------
	
	
	@Test
	public void filmFoundByCategory(){
		Category category =new Category();
		category.setName("Romance");
		List<Category> categories=new ArrayList<Category>();
		categories.add(category);
		List<Film> list=new ArrayList<Film>();
		Film film=new Film();
		film.setTitle("Rockstar");
		film.setCategory(categories);
		list.add(film);
		
		Mockito.when(filmRepository.searchFilmByCategory(category)).thenReturn(list);
		
		list=filmService.searchFilmByCategory(category);
		Iterator<Film> it=list.iterator();
		categories=it.next().getCategory();
		Iterator<Category> itc=categories.iterator();
		assertEquals("Romance",itc.next().getName());
		
	}
	
	@Test
	public void  filmNotFoundByCategory(){
		List<Film> list=new ArrayList<Film>();
		Category category =new Category();
		category.setName("Romance");
		
		Mockito.when(filmRepository.searchFilmByCategory(category)).thenReturn(list);
		
		assertTrue(filmService.searchFilmByCategory(category).isEmpty());
	
		
	}
	
	
	

	@Test(expected=IllegalArgumentException.class)
	public void categoryIsNull(){
		filmService.searchFilmByCategory(null);
	}
	
	

	
	
	//---------------------------SearchByRating--------------------------------------
	

	@Test
	public void  filmFoundByRating(){
		List<Film> list=new ArrayList<Film>();
		Film film=new Film();
		film.setTitle("Rockstar");
		film.setLanguage("Hindi");
		film.setRating((byte)2);
		
		list.add(film);
		
		Mockito.when(filmRepository.searchFilmByRating((byte)2)).thenReturn(list);
		list=filmService.searchFilmByRating((byte)2);
		Iterator<Film> it=list.iterator();
		assertEquals((byte)2,it.next().getRating());
		
	}
	
	@Test
	public void  filmNotFoundByRating(){
		List<Film> list=new ArrayList<Film>();
		
		Mockito.when(filmRepository.searchFilmByRating((byte)1)).thenReturn(list);
		
		assertTrue(filmService.searchFilmBytitle("Rockon").isEmpty());
	
		
	}
	
	
	
	
	
	
	
	
	
	//-----------------------------searchByLAnguage-------------------------------------
	
	@Test(expected=IllegalArgumentException.class)
	public void LanguageIsNull(){
		filmService.searchFilmByLanguage(null);
	}
	
	
	@Test
	public void  filmFoundByLnguage(){
		List<Film> list=new ArrayList<Film>();
		Film film=new Film();
		film.setTitle("Rockstar");
		film.setLanguage("Hindi");
		list.add(film);
		
		Mockito.when(filmRepository.searchFilmByLanguage("Hindi")).thenReturn(list);
		list=filmService.searchFilmByLanguage("Hindi");
		Iterator<Film> it=list.iterator();
		assertEquals("Hindi",it.next().getLanguage());
		
	}
	
	@Test
	public void  filmNotFoundByLanguage(){
		List<Film> list=new ArrayList<Film>();
		
		Mockito.when(filmRepository.searchFilmBytitle("Hindi")).thenReturn(list);
		
		assertTrue(filmService.searchFilmBytitle("Rockon").isEmpty());
	
		
	}
	
	
	
	
	
	
	
	
	
	
	//-----------------------SearchFilmByActor------------------------------
	
	//
	
	@Test(expected=IllegalArgumentException.class)
	public void ActorIsNull(){
		filmService.searchFilmByActor(null);
	}
	
	
	@Test
	public void  filmFoundByActor(){
		List<Film> list=new ArrayList<Film>();
		Film film=new Film();
		film.setTitle("Rockstar");
		Actor actor=new Actor();
		actor.setFirstName("Ranbir");
		list.add(film);
		
		
		
		Mockito.when(filmRepository.searchFilmByActor(actor)).thenReturn(list);
		
		assertFalse(filmService.searchFilmByActor(actor).isEmpty());
		
		
	}
	
	@Test
	public void filmNotFoundByActor(){
		List<Film> list=new ArrayList<Film>();
		Actor actor=new Actor();
		actor.setFirstName("Ranbir");
		
		
		
		Mockito.when(filmRepository.searchFilmByActor(actor)).thenReturn(list);
		assertTrue(filmService.searchFilmByActor(actor).isEmpty());
	}
	
	
	//-----------------------------------Delete Film-----------------------------------------
	
	@Test
	public void deleteFilmSuccessfull(){
		Mockito.when(filmRepository.deleteFilm("Rockon")).thenReturn("success");
		assertEquals("success", filmService.deleteFilm("Rockon"));
		
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void TitleIsNull(){
		filmService.deleteFilm(null);
	}
	
	
	

}
