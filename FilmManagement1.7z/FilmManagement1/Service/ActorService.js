/**
 * Created by VINAY on 7/6/2016.
 */
/**
 * Created by vraghuva on 7/4/2016.
 */

helloApp.factory('actorService', function($http){
    return function (cb) {
        $http({
            method:'GET',
            url:'Data/Actor.json'
        }).then(function (response) {
            cb(response.data)

        }),function (response) {
            console.log("something wrong");

        }


    }


});
