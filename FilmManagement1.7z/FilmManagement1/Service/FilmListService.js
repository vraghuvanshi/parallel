/**
 * Created by VINAY on 7/6/2016.
 */

helloApp.factory('filmListService', function($http){
    return function (cb) {
        $http({
            method:'GET',
            url:'Data/Film.json'
        }).then(function (response) {
            cb(response.data)

        }),function (response) {
            console.log("something wrong");

        }


    }


});