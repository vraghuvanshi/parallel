/**
 * Created by VINAY on 7/6/2016.
 */

/**
 * Created by VINAY on 7/6/2016.
 */

helloApp.factory('actorModifyService', function($http){
    return function (cb) {
        $http({
            method:'GET',
            url:'Data/Actor.json'
        }).then(function (response) {
            cb(response.data)

        }),function (response) {
            console.log("something wrong");

        }


    }


});