/**
 * Created by VINAY on 7/6/2016.
 */

helloApp.controller("actorModifyController",function ($scope,actorModifyService) {


    function callback(obj) {
        $scope.actors=obj;
        $scope.showinfo=function (actor)
        {
            data=actor;
            console.log(data);
            document.getElementById("inputFirstName").value=actor.firstName;
            // document.getElementById("ReleaseYear").value=film.releaseYear;
            document.getElementById("inputLastName").value=actr.lastName;
            // document.getElementById("inputRating").value=film.rating;
            //  document.getElementById("Description").value=film.description;
            //document.getElementById("inputLength").value=film.length;
            var film=actors.films;
            console.log(actors);


        }
    }



    actorModifyService(callback);


});

