    /*$scope.sortBy="title";*/

    /**
     * Created by vraghuva on 7/4/2016.
     */

    var filmController=helloApp.controller('filmController',function ($scope,filmService) {

        var callBack=function (data) {
            $scope.films=data;
            console.log($scope.films);

        };
        filmService(callBack);

    });

