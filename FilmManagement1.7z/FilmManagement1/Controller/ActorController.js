/*$scope.sortBy="title";*/

/**
 * Created by vraghuva on 7/4/2016.
 */

var  actorController=helloApp.controller('actorController',function ($scope,actorService) {

    var callBack=function (data) {
        $scope.actors=data;
        console.log($scope.actors);

    };
    actorService(callBack);

});

/**
 * Created by VINAY on 7/6/2016.
 */
