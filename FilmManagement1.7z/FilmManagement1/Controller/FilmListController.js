helloApp.controller("filmListController",function ($scope,filmListService) {


    function callback(obj) {
        $scope.films=obj;
        $scope.showinfo=function (film)
        {
            data=film;
            console.log(data);
            document.getElementById("inputTitle").value=film.title;
           // document.getElementById("ReleaseYear").value=film.releaseYear;
            document.getElementById("inputLanguage").value=film.language;
           // document.getElementById("inputRating").value=film.rating;
          //  document.getElementById("Description").value=film.description;
            //document.getElementById("inputLength").value=film.length;
            var actors=film.actors;
            console.log(actors);


        }
    }



    filmListService(callback);


});
