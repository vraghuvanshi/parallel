/*
 * sortable_core.js
 */

(function($) {

module("sortable: core");

// this is here to make JSHint pass "unused", and we don't want to
// remove the parameter for when we finally implement
$.noop();

})(jQuery);
