package com.fms.Doa;


import java.util.List;

import com.fms.pojo.Actor;

public interface IActorDoa {
	
	public String save(Actor actor);
	List<Actor> searchActorByName(String firstyName, String LastName);
	List<Actor> searchByAge(byte age);
	String removeActor(Actor actor);
	String modifyActor(Actor actor);
	

}
