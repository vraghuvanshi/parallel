package com.fms.Doa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.fms.pojo.Actor;
import com.fms.pojo.Category;
import com.fms.pojo.Film;

public class FilmRepository implements IFilmDoa{
	
	EntityManagerFactory emFactory= Persistence.createEntityManagerFactory("hello");
	EntityManager em=emFactory.createEntityManager();

	public String addFilm(Film film) {
		
		
	
		return null;
		
	}

	public String modifyFilm(Film film) {
	
		
		return null;
	}

	public String deleteFilm(String title) {
	return null;	
	}

	public List<Film> searchFilmBytitle(String title) {
		
		return null;
	}

	public List<Film> searchFilmByCategory(Category category) {
		
		return null;
	}

	public List<Film> searchFilmByRating(byte rating) {
		
		return null;
	}

	public List<Film> searchFilmByLanguage(String language) {
		
		return null;
	}

	public List<Film> searchFilmByActor(Actor actor) {
		
		return null;
	}
	

}
