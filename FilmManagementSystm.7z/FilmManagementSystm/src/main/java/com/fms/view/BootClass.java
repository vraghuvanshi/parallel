package com.fms.view;

public class BootClass {

	public static void main(String[] args) {
		

	}

}
