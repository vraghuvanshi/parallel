package com.fms.service;

import static org.junit.Assert.*;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.fms.Doa.IActorDoa;
import com.fms.pojo.Actor;


public class ActorServiceTest {

private ActorService actorService;
	
	@Mock private IActorDoa actorRepository;
	
	
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
	 actorService=new ActorService(actorRepository);
		
	}
	
	//-------------AddActor---------------------
	
	@Test(expected=IllegalArgumentException.class)
	public void actorIsNull(){
		actorService.addActor(null);
		
	}
	
	
	@Test
	public void actorDetailsAdded() {
		Actor actor=new Actor();
		actor.setFirstName("Ranbir");
		actor.setLastName("Kapoor");
		actor.setGender("Male");
	
		
		Mockito.when(actorRepository.save(actor)).thenReturn("success");
		assertEquals("success",actorService.addActor(actor));
		
	}
	
	
	@Test(expected=Exception.class)
	public void actorDetailsNotAdded() {
		Actor actor=new Actor();
		actor.setFirstName("Ranbir");
		actor.setLastName("Kapoor");
		actor.setGender("Male");
	
		
		Mockito.when(actorRepository.save(actor)).thenThrow(new Exception("Error"));
				actorService.addActor(actor);	
	}
	
	
	
	
	
	//------------ModifyActor-------------------------
	
	
	
	@Test(expected=IllegalArgumentException.class)
	public void ActorToMOdifyIsNull(){
		actorService.modifyActor(null);
	}
	
	
	
	@Test
	public void actorIsModified(){
		
		Actor actor=new Actor();
		actor.setFirstName("Rishi");
		actor.setLastName("Kapoor");
		actor.setGender("Male");
		
		Mockito.when(actorRepository.modifyActor(actor)).thenReturn("success");
		assertEquals("success",actorService.modifyActor(actor));
	}
	

	@Test(expected=Exception.class)
	public void actorIsNotModified(){
		
		Actor actor=new Actor();
		actor.setFirstName("Rishi");
		actor.setLastName("Kapoor");
		actor.setGender("Male");
		
		Mockito.when(actorRepository.modifyActor(actor)).thenThrow(new Exception("Error"));
		actorService.modifyActor(actor);
	}
	
	
	
	
	
	//-----------------------SearchByNAme------------------------------
	
	
	@Test(expected=IllegalArgumentException.class)
	public void nameIsNull(){
		actorService.searchActorByName(null, null);
		
	}
	
	@Test
	public void actorFoundByName(){
		List<Actor> list=new ArrayList<Actor>();
		
		Actor actor=new Actor();
		actor.setFirstName("Ranbir");
		actor.setLastName("Kapoor");
		
		list.add(actor);
		
		Mockito.when(actorRepository.searchActorByName("Ranbir", "Kapoor")).thenReturn(list);
		
		list=actorService.searchActorByName("Ranbir", "Kapoor");
		Iterator<Actor> it=list.iterator();
		assertEquals("Ranbir",it.next().getFirstName());
		
		
	}
	
	@Test
	public void actorNotExist(){
		List<Actor> list=new ArrayList<Actor>();
		
		Mockito.when(actorRepository.searchActorByName("Ranveer", "Singh")).thenReturn(list);
		assertTrue(actorService.searchActorByName("Ranveer", "Singh").isEmpty());
	}
	
	@Test(expected=Exception.class)
	public void actorFoundByNameSystemError(){
		Mockito.when(actorRepository.searchActorByName("Ranveer", "Kapoor")).thenThrow(new Exception("Error"));
		actorService.searchActorByName("Ranveer","Kapoor");
		
	}
	
	//----------------------DeleteActor---------------------------
	
	
	@Test(expected=IllegalArgumentException.class)
	public void actorToDeleteIsNull(){
		actorService.deleteActor(null);
	}
	
	
	@Test
	public void actorDeleteSuccessfull(){
		Actor actor=new Actor();
		actor.setFirstName("Ranbir");
		actor.setLastName("Kapoor");
		actor.setGender("Male");
	
		
		Mockito.when(actorRepository.removeActor(actor)).thenReturn("success");
		assertEquals("success",actorService.deleteActor(actor));
		
	}
	
	@Test(expected=Exception.class)
	public void actorIsNotDeleted(){
		Actor actor=new Actor();
		actor.setFirstName("Ranbir");
		actor.setLastName("Kapoor");
		actor.setGender("Male");
	
		
		Mockito.when(actorRepository.removeActor(actor)).thenThrow(new Exception("Error"));
		actorService.deleteActor(actor);
	}
	
	
	//------------------searchByAge-----------------------
	
	
	
	@Test(expected=IllegalArgumentException.class)
	public void AgeIsZero(){
		actorService.searchActorByAge((byte)0);
	}
	
	@Test
	public void actorFoundByAge(){
		List<Actor> list=new ArrayList<Actor>();
		
		Actor actor=new Actor();
		actor.setFirstName("Ranbir");
		actor.setLastName("Kapoor");
		actor.setAge((byte)65);
		
		list.add(actor);
		
		Mockito.when(actorRepository.searchByAge((byte)65)).thenReturn(list);
		
		list=actorService.searchActorByAge((byte)65);
		Iterator<Actor> it=list.iterator();
		assertEquals(65,(int)it.next().getAge());
		
		
	}
	@Test
	public void actorNotFound(){
		List<Actor> list=new ArrayList<Actor>();
		
		Mockito.when(actorRepository.searchByAge((byte) 78)).thenReturn(list);
	}
	
	@Test(expected=Exception.class)
	public void actorFoundByAgeSystemError(){
		Mockito.when(actorRepository.searchByAge((byte)2)).thenThrow(new Exception("Error"));
		actorService.searchActorByAge((byte)2);
		
	}
	
	
}
