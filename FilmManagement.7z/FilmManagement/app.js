/**
 * Created by vraghuva on 7/1/2016.
 */

var helloApp= angular.module('helloApp', ['ngResource', 'ngRoute'])
    .config(function($routeProvider){
        $routeProvider.when('/Home',{

            templateUrl:'Template/Home.html'
            //controller: 'FilmController'

        });

        $routeProvider.when('/AddFilm',{

            templateUrl:'Template/Film/AddFilm.html'
        });

        $routeProvider.when('/ModifyFilm',{

            templateUrl:'Template/Film/ModifyFilm.html'
        });
        $routeProvider.when('/Film',{

            templateUrl:'Template/Film/Film.html',
            controller: 'FilmController'
        });

        $routeProvider.when('/SearchFilm',{

            templateUrl:'Template/Film/SearchFilm.html',

        });






        $routeProvider.otherwise({redirectTo:'/Home'});

      
    });
