/**
 * Created by vraghuva on 7/1/2016.
 */

var helloApp= angular.module('helloApp', ['ngResource', 'ngRoute'])
    .config(function($routeProvider){
        $routeProvider.when('/Home',{

            templateUrl:'Template/Home.html'
            //controller: 'FilmController'

        });

        $routeProvider.when('/AddFilm',{

            templateUrl:'Template/Film/AddFilm.html'
        });


        $routeProvider.otherwise({redirectTo:'/Home'});

      
    });
