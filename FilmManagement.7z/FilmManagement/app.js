/**
 * Created by vraghuva on 7/1/2016.
 */

var helloApp= angular.module('helloApp', ['ngResource', 'ngRoute'])
    .config(function($routeProvider){
        $routeProvider.when('/Home',{

            templateUrl:'Template/Home.html'
            //controller: 'FilmController'

        });

        $routeProvider.when('/AddFilm',{

            templateUrl:'Template/Film/AddFilm.html'
        });

        $routeProvider.when('/ModifyFilm',{

            templateUrl:'Template/Film/ModifyFilm.html'
        });
        $routeProvider.when('/Film',{

            templateUrl:'Template/Film/Film.html',
            controller: 'filmController'
        });

        $routeProvider.when('/SearchFilm',{

            templateUrl:'Template/Film/SearchFilm.html'

        });
        $routeProvider.when('/AddActor',{

            templateUrl:'Template/Actor/AddActor.html'

        });
        $routeProvider.when('/ModifyActor',{

            templateUrl:'Template/Actor/ModifyActor.html'

        });
        $routeProvider.when('/SearchActor',{

            templateUrl:'Template/Actor/SearchActor.html'

        });
        $routeProvider.when('/Actor',{

            templateUrl:'Template/Actor/Actor.html'

        });








        $routeProvider.otherwise({redirectTo:'/Home'});

      
    });
