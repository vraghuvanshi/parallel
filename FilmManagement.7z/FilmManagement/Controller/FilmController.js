/**
 * Created by vraghuva on 7/4/2016.
 */

var filmController=helloApp.controller('filmController',function ($scope,FilmService) {
    $scope.sortBy="title";

    
    var callBack=function (data) {
        $scope.blogs=data;


    }
    blogService(callBack);

});

