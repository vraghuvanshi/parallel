/**
 * Created by vraghuva on 7/4/2016.
 */

helloApp.factory('blogService', function($http){
    return function (cb) {
        $http({
            method:'GET',
            url:'Data/Data.json'
        }).then(function (response) {
            cb(response.data)

        }),function (response) {
            console.log("something wrong");

        }


    }


});
